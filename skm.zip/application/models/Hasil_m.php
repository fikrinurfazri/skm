<?php

class Hasil_m extends CI_Model
{
    public function getuser()
    {

        return $this->db->get_where('admin', ['ID_ADMIN' => $this->session->userdata('ID_ADMIN')])->row_array();
    }
    public function hitungresponden()
    {
        $data = $this->db->get_where('admin', ['ID_ADMIN' => $this->session->userdata('ID_ADMIN')])->row_array();
        $this->db->select_sum('U1')
            ->from('t_skm');
    }

    public function getall()
    {
        return $this->db->select('*')
            ->from('m_nilai')
            ->join('m_unsur ', 'm_unsur.ID_UNSUR = m_nilai.ID_UNSUR')
            ->get()->result_array();
    }
    public function U1()
    {
        $table = 't_skm';
        $field = 'U1';
        $this->db->select_sum($field);
        $query = $this->db->get($table);
        $sum = $query->row()->$field;
        return $sum;
    }
    public function U2()
    {
        $table = 't_skm';
        $field = 'U2';
        $this->db->select_sum($field);
        $query = $this->db->get($table);
        $sum = $query->row()->$field;
        return $sum;
    }
    public function U3()
    {
        $table = 't_skm';
        $field = 'U3';
        $this->db->select_sum($field);
        $query = $this->db->get($table);
        $sum = $query->row()->$field;
        return $sum;
    }
    public function U4()
    {
        $table = 't_skm';
        $field = 'U4';
        $this->db->select_sum($field);
        $query = $this->db->get($table);
        $sum = $query->row()->$field;
        return $sum;
    }
    public function U5()
    {
        $table = 't_skm';
        $field = 'U5';
        $this->db->select_sum($field);
        $query = $this->db->get($table);
        $sum = $query->row()->$field;
        return $sum;
    }
    public function U6()
    {
        $table = 't_skm';
        $field = 'U6';
        $this->db->select_sum($field);
        $query = $this->db->get($table);
        $sum = $query->row()->$field;
        return $sum;
    }
    public function U7()
    {
        $table = 't_skm';
        $field = 'U7';
        $this->db->select_sum($field);
        $query = $this->db->get($table);
        $sum = $query->row()->$field;
        return $sum;
    }
    public function U8()
    {
        $table = 't_skm';
        $field = 'U8';
        $this->db->select_sum($field);
        $query = $this->db->get($table);
        $sum = $query->row()->$field;
        return $sum;
    }
    public function U9()
    {
        $table = 't_skm';
        $field = 'U9';
        $this->db->select_sum($field);
        $query = $this->db->get($table);
        $sum = $query->row()->$field;
        return $sum;
    }
}
