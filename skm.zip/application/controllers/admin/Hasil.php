<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Hasil extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('hasil_m');
        $this->load->model('auth_m');
        if (!$this->auth_m->current_user()) {
            redirect('auth/login');
        }
    }
    public function index()
    {
        $data['user'] = $this->hasil_m->getuser();
        $data['U1'] = $this->hasil_m->U1();
        $data['U2'] = $this->hasil_m->U2();
        $data['U3'] = $this->hasil_m->U3();
        $data['U4'] = $this->hasil_m->U4();
        $data['U5'] = $this->hasil_m->U5();
        $data['U6'] = $this->hasil_m->U6();
        $data['U7'] = $this->hasil_m->U7();
        $data['U8'] = $this->hasil_m->U8();
        $data['U9'] = $this->hasil_m->U9();
        // $data['responden'] = $this->hasil_m->hitungresponden();
        $data['getnilai'] = $this->db->get('t_skm')->result_array();
        $query = $this->db->get('t_skm');
        $data['responden'] = $query->num_rows();

        $this->load->view('pages/admin/head');
        $this->load->view('pages/admin/nav', $data);
        $this->load->view('admin/hasil');
        $this->load->view('pages/admin/footer');
    }
}
